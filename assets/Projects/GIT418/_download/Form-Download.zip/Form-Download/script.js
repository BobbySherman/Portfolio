/**
    GIT417: Tutorial Form Script
    Author: Bobby Sherman
    Date:   10/5/21
*/

"use strict";
// Global Variables


// Function to check for empty inputs



// Function to validate form



// Event Listeners
function createEventListeners() {
    // submit listner
    var contactForm = document.getElementsByTagName("form")[0];
    contactForm.addEventListener("submit", validateForm, false);
}


// window load triggers createEventListener
window.addEventListener("load", createEventListeners, false);