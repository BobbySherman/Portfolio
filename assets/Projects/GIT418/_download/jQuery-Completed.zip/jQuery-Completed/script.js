/**
    GIT418: Tutorial2 jQuery Animation Script
    Author: Bobby Sherman
    Date:   11/30/21
*/
"use strict";

// SELECTORS
// $("button").click(function() {
//     $("div").animate({left: "400px"});
// });

// $("button:first").click(function() {
//     $(this).animate({left: "400px"});
// });

$(".move").click(function() {
    $("#rectangle-move").animate({left: "400px"});
});


// MOVE RIGHT - FAST
$(".fast").click(function() {
    $("#rectangle-fast").animate({left: "400px"}, "fast");
});


// SLIDE TOGGLE
$(".slideToggle").click(function() {
    $("#rectangle-toggle").slideToggle(1000);
});


// HIDE
$(".hide").click(function() {
    $("#rectangle-hide").hide("slow");
});

$(".show").click(function() {
    $("#rectangle-hide").show("fast");
});

$(".hide-toggle").click(function() {
    $("#rectangle-hide").toggle(2000);
});


// FADE TOGGLE
$(".fadeToggle").click(function() {
    $("#rectangle-fade").fadeToggle("fast");
});


// BONUS: COMBINE ANIMATIONS
$(".animate").click(function() {
    $("#rectangle-animate").animate({
        width: "toggle", 
        opacity: "toggle"
    },
        "slow",
        "swing"
    );
});
