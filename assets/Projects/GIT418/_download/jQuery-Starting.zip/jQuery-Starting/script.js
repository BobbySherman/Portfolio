/**
    GIT418: Tutorial2 jQuery Animation Script
    Author: Bobby Sherman
    Date:   11/30/21
*/
"use strict";

// SELECTORS


// MOVE RIGHT


// MOVE RIGHT - FAST


// SLIDE TOGGLE


// HIDE


// FADE TOGGLE


// BONUS: COMBINE ANIMATIONS

