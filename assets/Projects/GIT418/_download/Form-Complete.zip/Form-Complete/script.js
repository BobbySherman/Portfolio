/**
    GIT417: Tutorial Form Script
    Author: Bobby Sherman
    Date:   10/5/21
*/

"use strict";
// global Variables
var formValidity = true;
var inputValid = true;


// Function to check for empty inputs
function validateRequiredInputs() {
    var formInputs = document.querySelectorAll("#contactForm input"); // assign all contact inputs
    var userMessage = document.querySelector("#userMessage"); // assign message div

    // check for empty inputs
    try {
        var currentInput; // variable for current input

        for (var i = 0; i < 3; i++) {
            currentInput = formInputs[i]; // current input
            // apply border + input validity if empty
            if (currentInput.value === "") {
                currentInput.style.border = "1.5px solid red"; // apply border
                inputValid = false; // progress to throw and catch
            } else {
                // reset Border and Input Validity
                currentInput.style.border = "";
                inputValid = true;
            }
        }

        // throw message if not valid
        if (inputValid === false) {
            throw "Please fill the outlined fields";
        } else {
            // reset message div
            userMessage.innerHTML = "";
            userMessage.style.border = "";
            userMessage.style.padding = "";
            userMessage.style.marginBottom = "";
        }
    }

    // if any input is empty show message
    catch(msg) {
        // apply css style
        userMessage.style.border = "2px solid red";
        userMessage.style.padding = "9px";
        userMessage.style.marginBottom = "20px";
        // show message
        userMessage.textContent = msg;
        formValidity = false; // no submit
    }
}


// function to validate form
function validateForm(evt) {
    evt.preventDefault(); // trap submit event
    formValidity = true; // reset form validity on button click
    validateRequiredInputs(); // call function

    // if validateRequiredInputs returns formValidity = true
    if (formValidity === true) {
        document.forms[0].submit(); // submit form
    }
}

// Event Listeners
function createEventListeners() {
    // submit listner
    var contactForm = document.getElementsByTagName("form")[0];
    contactForm.addEventListener("submit", validateForm, false);
}


// window load triggers createEventListener
window.addEventListener("load", createEventListeners, false);